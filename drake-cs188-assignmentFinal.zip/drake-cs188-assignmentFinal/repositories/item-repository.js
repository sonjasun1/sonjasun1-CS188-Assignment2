let items = [
  {
    'description': 'Drake Sweatpants',
    'item_id': 'd83ff143-9f8b-445a-8d8f-b9b8fe0f9f30',
    'price': 20
  }
];

const selectItems = () => ({
rows: items
});

const selectItemByItemId = (itemId) =>
items.find((item) => item['item_id'] === itemId);

const insertItem = (item) => items.push(item);

const updateItem = (updatedItem) => {
const itemsThatDontMatch = items.filter((item) =>
item['item_id'] !== updatedItem['item_id']
);

items = [
...itemsThatDontMatch,
updatedItem
];
};

const deleteItemByItemId = (itemId) => {
items = items.filter((item) =>
item['item_id'] !== itemId
);
};

module.exports = {
deleteItemByItemId,
insertItem,
selectItemByItemId,
selectItems,
updateItem
};
